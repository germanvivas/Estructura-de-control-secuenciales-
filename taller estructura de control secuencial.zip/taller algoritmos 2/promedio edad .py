#entrada
edad_uno=int(input("ingrese edad 1: "))
edad_dos=int(input("ingrese edad 2: "))
edad_tres=int(input("ingrese edad 3: "))
#caja negra
promedio=(edad_uno+edad_dos+edad_tres)/3
#salidas
print("este es el promedio: ",promedio)
