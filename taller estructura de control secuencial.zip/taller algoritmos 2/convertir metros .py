#entradas
metros=float(input("Ingrese una cantidad en metros: "))
#caja negra
pulgadas=metros*39.37
pies=metros*3.281
#salidas
print("Metros convertidos a pulgadas es: ",pulgadas)
print("Metros convetidos a pies es: ",pies)