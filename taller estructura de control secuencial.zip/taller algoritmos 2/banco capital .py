#entrada
capital=int(input("ingrese capital invertido: "))
#caja negra
ganancia=(capital*.02)
#salidas
print("La ganancia por el capital invertido es: $",ganancia)
print("La ganancia ya con el capital invertodo es: $",ganancia+capital)

