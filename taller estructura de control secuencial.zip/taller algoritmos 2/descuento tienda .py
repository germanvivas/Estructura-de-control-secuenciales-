#entradas
total=float(input("ingresa el total de la compra: "))
#caja negra
descuento=(total * .15)
#salidas
print("El total a pagar es: $",total-descuento)
print("El descuento aplicado es: $",descuento)