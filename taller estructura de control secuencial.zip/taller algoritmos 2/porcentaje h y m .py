#entradas
mujeres=int(input("Ingrese el nuemro de mujeres: "))
hombres=int(input("Ingrese el numero de hombres: "))
#caja negra
total=(mujeres+hombres)
#salidas
print("El porcentaje de mujeres es: ",(mujeres/total)*100,"%")
print("El porcentaje de hombres es: ",(hombres/total)*100,"%")
